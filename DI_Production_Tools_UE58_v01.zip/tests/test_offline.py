"""Offline Python smoke tests: do not claim this substitutes for launching UE 5.8."""
import json
import pathlib
import sys
import tempfile
import types
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Plugins" / "DIProductionTools" / "Content" / "Python"))
TEST_DIR = tempfile.TemporaryDirectory()

unreal = types.ModuleType("unreal")
unreal.log = lambda s: None
unreal.log_error = lambda s: None
unreal.log_warning = lambda s: None
unreal.Paths = types.SimpleNamespace(project_saved_dir=lambda: TEST_DIR.name)
unreal.StaticMesh = type("StaticMesh", (), {})
unreal.AnimSequence = type("AnimSequence", (), {})
unreal.LevelSequence = type("LevelSequence", (), {})
sys.modules["unreal"] = unreal

from di_toolkit import core, environment, cinematic  # noqa: E402


class FakeMesh(unreal.StaticMesh):
    def __init__(self, name, uv=1, slots=1, vertices=50):
        self.name, self.uv, self.slots, self.vertices = name, uv, slots, vertices

    def get_path_name(self):
        return "/Game/Test/" + self.name

    def get_name(self):
        return self.name

    def get_num_lods(self):
        return 1

    def get_num_tex_coords(self, lod):
        return self.uv

    def get_num_vertices(self, lod):
        return self.vertices

    def get_num_triangles(self, lod):
        return 12

    def get_num_sections(self, lod):
        return 1

    def get_editor_property(self, name):
        if name == "static_materials":
            return [types.SimpleNamespace(material_interface=object()) for _ in range(self.slots)]
        if name == "body_setup":
            return None
        raise AttributeError(name)


class TestOffline(unittest.TestCase):
    def test_config(self):
        cfg = core.load_config()
        self.assertEqual(cfg["building_actor_tag"], "DI_Building")
        import re
        pat = cfg["building_name_pattern"]
        self.assertTrue(re.search(pat, "BP_R09_Building"))
        self.assertTrue(re.search(pat, "L01_McDonald"))
        self.assertFalse(re.search(pat, "LampPost_123"))

    def test_static_mesh_reports(self):
        report = core.Report("test_mesh", "mock")
        cfg = core.load_config()
        m1, m2 = FakeMesh("SM_L01_OK"), FakeMesh("SM_R09_BAD", uv=0, slots=0, vertices=0)
        for mesh in [m1, m2]:
            report.examined += 1
            environment._inspect_mesh(mesh, cfg, report)
        path = pathlib.Path(report.save())
        self.assertTrue(path.exists())
        payload = json.loads(path.read_text(encoding="utf8"))
        self.assertEqual(payload["examined"], 2)
        self.assertTrue(any(x["code"] == "NO_UV0" for x in payload["issues"]))
        self.assertTrue(any(x["code"] == "NO_MATERIAL_SLOTS" for x in payload["issues"]))
        self.assertTrue(path.with_suffix(".csv").exists())

    def test_readonly(self):
        src = (ROOT / "Plugins" / "DIProductionTools" / "Content" / "Python" / "di_toolkit")
        for name in ["environment.py", "cinematic.py"]:
            content = (src / name).read_text(encoding="utf8")
            for prohibited in ["set_editor_property(", "set_actor_location(", "save_asset(", "delete_asset("]:
                self.assertNotIn(prohibited, content)

    def test_binding_fallback(self):
        seq = object()
        self.assertIsNone(cinematic._bindings_from_sequence(seq))
        self.assertIsNone(cinematic._tracks_from_sequence(seq))


if __name__ == "__main__":
    unittest.main()
