# DI Production Tools v0.1 — UE 5.8

**목적:** 동인천 Phase 2의 실제 Production 이슈를 Unreal Editor 안에서 읽기 전용으로 자동 검사한다.

**상태:** Python 문법 및 가상 Unreal 객체를 사용하는 오프라인 스모크 테스트 통과를 목표로 작성. **실제 UE 5.8 Editor와 사용자의 프로젝트/맵에서는 아직 실행 테스트하지 않았다.** Unreal API/프로젝트 네이밍에 따라 조정이 필요할 수 있다.

## 패키지 구성

- `Plugins/DIProductionTools/DIProductionTools.uplugin` — 프로젝트에 설치하는 Editor 전용 도구 플러그인
- `Plugins/DIProductionTools/Content/Python/init_unreal.py` — Editor 시작 시 메뉴 등록
- `Plugins/DIProductionTools/Content/Python/di_toolkit/environment.py` — 건물 Actor/Static Mesh/지면 검사
- `Plugins/DIProductionTools/Content/Python/di_toolkit/cinematic.py` — AnimSequence/Sequencer 검사
- `Plugins/DIProductionTools/Content/Python/di_toolkit/menu.py` — UE 상단 **DI Tools** 메뉴
- `Plugins/DIProductionTools/Config/DI_Toolkit.json` — 프로젝트별 기준값과 네이밍 설정
- `tests/test_offline.py` — Unreal 미설치 환경에서의 제한적 스모크 테스트

## 설치

1. UE 에디터를 종료한다. **프로젝트 전체 백업 또는 소스컨트롤 커밋을 먼저 한다.**
2. 본 ZIP의 `Plugins/DIProductionTools` 폴더를 `프로젝트폴더/Plugins/DIProductionTools`에 복사한다. `Plugins` 폴더가 없으면 생성한다.
3. Unreal 5.8에서 프로젝트를 실행하고, **Edit > Plugins**에서 `Python Editor Script Plugin`, `Editor Scripting Utilities`, `Sequencer Scripting`, `Dongincheon Production Tools`를 활성화한다. (의존 플러그인 활성화를 요구하면 승인.)
4. Editor를 재시작한다.
5. 상단 메뉴에 **DI Tools**가 보이면 준비 완료. 메뉴가 없다면 **Output Log > Python** 모드에서 `import di_toolkit; di_toolkit.register_menus()`를 입력한다.
6. 메뉴 등록에 실패하거나 예외가 나면 Output Log의 `[DI Tools]` 메시지를 보관한다. Python 콘솔에서 바로 `import di_toolkit; di_toolkit.environment.scan_buildings()` 등으로 실행할 수도 있다.

## 메뉴 명령

| 명령 | 동작 |
|---|---|
| 01 Environment / Scan all named buildings | 로드된 현재 레벨의 `L01/R09/...` 명명 규칙 또는 `DI_Building` 태그 건물 검사 |
| 02 Environment / Scan selected actors | Outliner에서 선택한 Actor의 Mesh 연결, Placeholder 의심, Bounds/Scale 점검 |
| 03 Assets / Validate selected StaticMeshes | Content Browser에서 선택한 Static Mesh의 UV0, 재질 슬롯, 지오메트리/LOD 검사 |
| 04 Assets / Validate building StaticMeshes | 현재 레벨 건물 Actor가 참조하는 Static Mesh 검사 |
| 05 Environment / Probe ground under selected | 현재 선택 Actor Bounds 하단의 5지점 Visibility Raycast. **조사만 하며 이동하지 않음** |
| 06 Animation / Validate selected AnimSequences | 선택한 Animation Sequence의 Skeleton/Length/Root Motion 플래그 및 QTE root 이동량 확인 |
| 07 Sequencer / Validate open Sequence | 열려 있는 Level Sequence의 Binding/Camera Cut/애니메이션 섹션 확인 |
| 08 Sequencer / Validate selected Sequences | Content Browser에서 선택한 Level Sequence 검사 |
| 09 QA / Select problem actors from last scan | 마지막 스캔의 WARN/FAIL Actor를 Outliner에서 선택 |
| 10 QA / Focus problem assets from last scan | 마지막 스캔의 WARN/FAIL Asset을 Content Browser에서 선택 |
| 11 QA / Print last report path | 마지막 결과 JSON 파일 경로를 Output Log에 표시 |

## 보고서

- 저장: `프로젝트/Saved/DI_Toolkit/YYYYMMDD_HHMMSS_microseconds_<tool>.json` 및 `.csv`
- 결과: `FAIL` / `WARNING` / `INFO` / `SKIP` (SKIP은 통과가 아닌 **검사 미완료**)
- 복잡한 모델링 품질, UV island 비율, Lightmap UV 유효성, 텍스처 밀도, 건물 실루엣 비교는 자동 판정하지 않는다.

## 환경 검사 주의

- `DI_Toolkit.json`의 `building_name_pattern`으로 검사 범위를 조정할 수 있다. 경로는 **플러그인의 Config 폴더**이다.
- R/L/C 번호 네이밍이 Actor Label에 없으면 `DI_Building` Actor Tag로 지정한다.
- 지면은 `DI_Ground` Actor Tag를 달거나 `road`, `ground`, `landscape` 등의 단어가 Actor Label에 포함되어야 한다.
- 지면 Actor가 **Visibility 채널에 Block 응답하는 Collision**을 가져야 레이캐스트가 가능하다.
- **AABB 하단은 실제 건물 기초면이 아니다.** 처마/돌출 장식/회전 건물/경사로/지면과 건물이 겹친 경우 경고 결과는 **후보**이며 직접 확인해야 한다.
- 자동으로 Actor를 이동시키거나 Static Mesh/Animation/Sequencer 값을 수정하지 않는다. 검사 중 문제가 있으면 `SKIP`으로 표시하고 원본을 보존한다.
- Whitebox 발견은 주로 이름 기반의 의심 후보일 뿐, 실제 재질이 새하얀지를 시각 인식하지 않는다.

## 애니메이션/시네마틱 검사 주의

- QTE AnimSequence 이름에 QTE 등의 토큰이 있어야 Root Track 분석을 시도한다.
- 루트 본의 원본 시작/끝 Pose Translation은 **애니메이션 자체의 참고 지표**이며 Sequence의 최종 캐릭터 World 위치나 정합을 증명하지 않는다.
- `enable_root_motion=False`는 반드시 오류가 아니다. Sequencer, Motion Warping, Montage 경로마다 처리가 다르므로 기본은 INFO로 기록한다.
- **현재 플레이하는 Player/Boss에 대한 동적 Binding이 정확한지, 카메라가 부드럽게 복귀하는지, QTE Time Dilation이 원복되는지는 PI E(Play In Editor) 실제 플레이로 검사해야 한다.** 이것을 자동 PASS로 표기하지 않는다.
- Actor Binding 이름의 필수 토큰은 설정의 `cinematic_required_binding_keywords`에 명시했을 때만 WARNING을 발생시킨다.

## 즉시 검증 시나리오

1. 빈 테스트 레벨에서 `SM_*` Actor를 선택하고 메뉴 02 실행 -> 오류 없이 JSON/CSV 생성 확인.
2. Content Browser에서 정상 StaticMesh 및 재질/UV 이상 Mesh 하나씩 선택하고 메뉴 03 -> 정확한 WARN/FAIL 확인.
3. 실제 `L01` 또는 `R09` 건물이 들어 있는 레벨에서 메뉴 01/04 -> 검사 대상 건물 개수 확인. `0개`면 정규식/태그부터 수정.
4. 건물과 도로 한 쌍을 테스트 레벨에서 선택해 메뉴 05 실행. `DI_Ground` 태그/Visibility Collision을 설정하고 지면 경고가 올바른지 확인.
5. `A_QTE01_Success_Player`를 선택하고 메뉴 06 실행. 기존의 Root Motion Flag가 보고서에 정확히 출력되는지 확인.
6. 열려 있는 실제 QTE Sequencer에서 메뉴 07을 실행. Animation Sections / Camera Cut 검수 및 `SKIP` 개수 확인.
7. 문제 Actor 자동 선택 기능(메뉴 09) 동작 확인.

## 명확히 제외한 것(v0.1)

- `Editor Utility Widget` 도킹 패널 에셋 (`.uasset`) 생성: Unreal Editor가 없는 환경에서 실제 `.uasset`을 만들거나 테스트할 수 없으므로 **네이티브 ToolMenus 기반 메뉴를 채택**했다.
- 건물 자동 위치 변경/UV 자동 수정/Animation Root Motion 자동 변경/Sequencer Binding 자동 수정 — 원본 훼손 위험.
- 실제 게임 상태 진입/복귀 테스트 — Python Editor 도구와 Gameplay 런타임은 별개.

## 참고: 공식 API

- Python Editor API: https://dev.epicgames.com/documentation/en-us/unreal-engine/scripting-the-unreal-editor-using-python
- Unreal 5.8 Python API: https://dev.epicgames.com/documentation/en-us/unreal-engine/python-api/?application_version=5.8
- Unreal Sequencer Python: https://dev.epicgames.com/documentation/en-us/unreal-engine/python-scripting-in-sequencer-in-unreal-engine

**개선 계획:** UE 실제 테스트 통과 후 v0.2에서 문제 목록 테이블 + 문제 선택/포커스 + 항목별 재검사 EUW 패널 추가. v0.3에 안전한 Preview-only 지면 정렬 지원 검토.
